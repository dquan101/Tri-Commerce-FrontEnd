var config = {
    apiKey: "AIzaSyD-oRFO1w1M-aH2E0nPPDj9lv0gdERQ__M",
    authDomain: "crud-testing-e415d.firebaseapp.com",
    databaseURL: "https://crud-testing-e415d.firebaseio.com",
    projectId: "crud-testing-e415d",
    storageBucket: "crud-testing-e415d.appspot.com",
    messagingSenderId: "136831323659",
    appId: "1:136831323659:web:ef04b838d6bd1f3520c10e"
  };
  // Initialize Firebase
  firebase.initializeApp(config);
var ui = new firebaseui.auth.AuthUI(firebase.auth());
    var uiConfig = {
        callbacks: {
        signInSuccessWithAuthResult: function(authResult, redirectUrl) {
        // User successfully signed in.
        // Return type determines whether we continue the redirect automatically
        // or whether we leave that to developer to handle.
        return true;
        },
        uiShown: function() {
        // The widget is rendered.
        // Hide the loader.
        document.getElementById('loader').style.display = 'none';
        }
        },
        // Will use popup for IDP Providers sign-in flow instead of the default, redirect.
        signInFlow: 'popup',
        signInSuccessUrl: 'index.html',
        signInOptions: [
        // Leave the lines as is for the providers you want to offer your users.
        firebase.auth.GoogleAuthProvider.PROVIDER_ID,
        firebase.auth.FacebookAuthProvider.PROVIDER_ID,
        firebase.auth.EmailAuthProvider.PROVIDER_ID,
        ],
        // Terms of service url.
        tosUrl: '<your-tos-url>',
        // Privacy policy url.
        privacyPolicyUrl: '<your-privacy-policy-url>'
        };
            ui.start('#firebaseui-auth-container', uiConfig
        // Other config options...
        );
            var user = firebase.auth().currentUser;
            var photoURL;
            if (user != null) {
                photoURL = user.photoURL;
            }